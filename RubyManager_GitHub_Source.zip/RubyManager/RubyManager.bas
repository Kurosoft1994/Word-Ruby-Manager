Attribute VB_Name = "RubyManager"
Option Explicit

' ============================================================================
' RubyManager.bas
' Microsoft Word VBA - 日本語ルビ（フリガナ）一括管理
'
' 公開マクロは RubyManagerSystem_RubyFirst のみ。
' 補助処理はすべて Private とし、Alt+F8 のマクロ一覧に露出させない。
'
' 外部参照:
'   - Excel.Application.GetPhonetic を遅延バインディングで使用
'   - ADODB.Stream を遅延バインディングで使用し UTF-8 INI を読み書き
'
' 対応想定:
'   Microsoft Word 2016 / 2019 / 2021 / 2024 / Microsoft 365
'   日本語言語機能が有効であること
' ============================================================================

Private Const CONFIG_FILE_NAME As String = "ruby_config.ini"
Private Const CONFIG_VERSION As String = "1"

Private Type TRubyConfig
    LastMode As Long
    LastLevel As Long
    LastSingleMode As Long
    RubyRatio As Double
    LayoutMode As String
End Type

' ---------------------------------------------------------------------------
' 公開エントリポイント（Alt+F8 に表示させるのはこれだけ）
' ---------------------------------------------------------------------------
Public Sub RubyManagerSystem_RubyFirst()

    Dim doc As Document
    Dim cfg As TRubyConfig
    Dim dict As Object
    Dim xl As Object
    Dim mode As Long
    Dim level As Long
    Dim singleMode As Long
    Dim layoutMode As String
    Dim rubyRatio As Double
    Dim cfgPath As String
    Dim countChanged As Long
    Dim answer As String
    Dim oldScreenUpdating As Boolean

    On Error GoTo EH

    oldScreenUpdating = Application.ScreenUpdating
    Set doc = ActiveDocument

    If doc.Path = vbNullString Then
        MsgBox "この文書はまだ保存されていません。" & vbCrLf & _
               "先に文書を保存してから実行してください。", _
               vbExclamation, "RubyManager"
        Exit Sub
    End If

    cfgPath = doc.Path & Application.PathSeparator & CONFIG_FILE_NAME
    Set dict = CreateObject("Scripting.Dictionary")
    dict.CompareMode = 1 ' TextCompare

    Call RubyLoadConfig(cfgPath, cfg, dict)

    answer = RubyInputBoxWithHelp( _
        "処理モードを入力してください。" & vbCrLf & vbCrLf & _
        "1 ルビ追加：すべてに振る（全指定）" & vbCrLf & _
        "2 ルビ追加：ページの最初に出た単語だけ" & vbCrLf & _
        "3 ルビ追加：段落の最初に出た単語だけ" & vbCrLf & _
        "4 ルビ消去：すべて消去" & vbCrLf & _
        "5 ルビ消去：ページの最初のルビを残して重複削除" & vbCrLf & _
        "6 ルビ消去：段落の最初のルビを残して重複削除", _
        "RubyManager - モード", CStr(cfg.LastMode), _
        "1～6を入力します。" & vbCrLf & _
        "2は各ページで最初に見つかる対象語だけ、3は各段落で最初に見つかる対象語だけにルビを付けます。" & vbCrLf & _
        "5は各ページの最初の既存ルビを残し、それ以降の同一ページのルビを消します。" & vbCrLf & _
        "6は各段落について同様に処理します。" & vbCrLf & _
        "? または H でこの画面の詳細ヘルプを再表示できます。")

    If answer = vbNullString Then Exit Sub
    If Not RubyTryLong(answer, mode) Then
        MsgBox "1～6の数字を入力してください。", vbExclamation, "RubyManager"
        Exit Sub
    End If
    If mode < 1 Or mode > 6 Then
        MsgBox "1～6の数字を入力してください。", vbExclamation, "RubyManager"
        Exit Sub
    End If

    layoutMode = RubyInputBoxWithHelp( _
        "レイアウト補正を入力してください。" & vbCrLf & vbCrLf & _
        "0 なし" & vbCrLf & _
        "1 行間固定" & vbCrLf & _
        "2 テキストボックス文字あふれ調整" & vbCrLf & _
        "3 ページ境界維持（段落分割を抑制）" & vbCrLf & _
        "4 全適用" & vbCrLf & _
        "複数指定可：例 12、13、123", _
        "RubyManager - レイアウト", cfg.LayoutMode, _
        "0～4を組み合わせて指定します。例：12 は「行間固定＋テキストボックス調整」です。" & vbCrLf & _
        "4単独は全適用です。" & vbCrLf & _
        "ページ境界維持は、ルビを含む段落に KeepTogether/WidowControl を適用する保守的な方式です。" & vbCrLf & _
        "? または H で詳細ヘルプを表示できます。")
    If layoutMode = vbNullString Then Exit Sub
    If Not RubyValidateLayout(layoutMode) Then
        MsgBox "レイアウト指定が不正です。0～4だけを使用してください。", _
               vbExclamation, "RubyManager"
        Exit Sub
    End If

    If mode <= 3 Then

        answer = RubyInputBoxWithHelp( _
            "学習レベルを入力してください。" & vbCrLf & vbCrLf & _
            "1 入門：全漢字＋カタカナ" & vbCrLf & _
            "2 初級：基本漢字（N5相当・約80字）を自動スキップ" & vbCrLf & _
            "3 中級：N5＋N4相当（約300字）を自動スキップ" & vbCrLf & _
            "4 カスタム：辞書登録単語のみ", _
            "RubyManager - 学習レベル", CStr(cfg.LastLevel), _
            "1～4を入力します。" & vbCrLf & _
            "2と3の漢字リストはJLPTの実用的な近似リストです。JLPTは公式漢字一覧を公開していないため、厳密な公式分類ではありません。" & vbCrLf & _
            "4では ruby_config.ini の [Dictionary] に登録された単語だけが対象です。" & vbCrLf & _
            "? または H で詳細ヘルプを表示できます。")
        If answer = vbNullString Then Exit Sub
        If Not RubyTryLong(answer, level) Then
            MsgBox "1～4の数字を入力してください。", vbExclamation, "RubyManager"
            Exit Sub
        End If
        If level < 1 Or level > 4 Then
            MsgBox "1～4の数字を入力してください。", vbExclamation, "RubyManager"
            Exit Sub
        End If

        answer = RubyInputBoxWithHelp( _
            "単漢字の読み方を選択してください。" & vbCrLf & vbCrLf & _
            "1 音読み優先" & vbCrLf & _
            "2 訓読み固定" & vbCrLf & _
            "3 対話選択（履歴＋Excel推測候補）", _
            "RubyManager - 単漢字", CStr(cfg.LastSingleMode), _
            "単漢字（連続する漢字が1文字だけの箇所）に適用します。" & vbCrLf & _
            "3では該当箇所を画面表示・選択し、候補番号または直接入力できます。" & vbCrLf & _
            "選択した読みは自動的にカスタム辞書へ保存され、次回以降最優先になります。" & vbCrLf & _
            "? または H で詳細ヘルプを表示できます。")
        If answer = vbNullString Then Exit Sub
        If Not RubyTryLong(answer, singleMode) Then
            MsgBox "1～3の数字を入力してください。", vbExclamation, "RubyManager"
            Exit Sub
        End If
        If singleMode < 1 Or singleMode > 3 Then
            MsgBox "1～3の数字を入力してください。", vbExclamation, "RubyManager"
            Exit Sub
        End If

        answer = RubyInputBoxWithHelp( _
            "ルビ比率を入力してください（30～100）。" & vbCrLf & _
            "例：50 = 本文フォントサイズの50%をルビサイズにする", _
            "RubyManager - ルビ比率", RubyNumberToText(cfg.RubyRatio), _
            "WordのPhoneticGuide FontSize に指定するルビ文字サイズを、本文サイズ×比率で決めます。" & vbCrLf & _
            "標準値は50です。30～100の範囲を推奨します。" & vbCrLf & _
            "? または H で詳細ヘルプを表示できます。")
        If answer = vbNullString Then Exit Sub
        If Not RubyTryDouble(answer, rubyRatio) Then
            MsgBox "30～100の数値を入力してください。", vbExclamation, "RubyManager"
            Exit Sub
        End If
        If rubyRatio < 30 Or rubyRatio > 100 Then
            MsgBox "30～100の範囲で入力してください。", vbExclamation, "RubyManager"
            Exit Sub
        End If

        Set xl = RubyCreateExcel()
        If xl Is Nothing Then
            MsgBox "ExcelのGetPhoneticを利用できません。" & vbCrLf & _
                   "Excelがインストールされ、日本語言語機能が有効になっているか確認してください。", _
                   vbCritical, "RubyManager"
            Exit Sub
        End If

    Else
        level = cfg.LastLevel
        singleMode = cfg.LastSingleMode
        rubyRatio = cfg.RubyRatio
    End If

    cfg.LastMode = mode
    cfg.LastLevel = level
    cfg.LastSingleMode = singleMode
    If rubyRatio <= 0 Then rubyRatio = 50
    cfg.RubyRatio = rubyRatio
    cfg.LayoutMode = layoutMode

    ' 選択値を先に保存。対話中に中断しても設定は残る。
    Call RubySaveConfig(cfgPath, cfg, dict)

    oldScreenUpdating = Application.ScreenUpdating
    Application.ScreenUpdating = False

    Select Case mode
        Case 1, 2, 3
            countChanged = RubyProcessAddReverse(doc, mode, level, singleMode, _
                                                  rubyRatio, layoutMode, xl, dict)
        Case 4, 5, 6
            countChanged = RubyProcessDeleteReverse(doc, mode, layoutMode)
    End Select

    ' 学習辞書を含めた最終状態を保存
    Call RubySaveConfig(cfgPath, cfg, dict)

    Application.ScreenUpdating = oldScreenUpdating
    If Not xl Is Nothing Then
        On Error Resume Next
        xl.Quit
        Set xl = Nothing
        On Error GoTo 0
    End If

    MsgBox "RubyManagerの処理が完了しました。" & vbCrLf & _
           "変更件数：" & CStr(countChanged), _
           vbInformation, "RubyManager"
    Exit Sub

EH:
    On Error Resume Next
    Application.ScreenUpdating = oldScreenUpdating
    If cfgPath <> vbNullString Then RubySaveConfig cfgPath, cfg, dict
    If Not xl Is Nothing Then xl.Quit
    On Error GoTo 0

    MsgBox "処理中にエラーが発生しました。" & vbCrLf & _
           "番号：" & CStr(Err.Number) & vbCrLf & _
           "内容：" & Err.Description, _
           vbCritical, "RubyManager"
End Sub

' ---------------------------------------------------------------------------
' 追加処理：必ず末尾→先頭へ進む
' ---------------------------------------------------------------------------
Private Function RubyProcessAddReverse(ByVal doc As Document, _
                                       ByVal mode As Long, _
                                       ByVal level As Long, _
                                       ByVal singleMode As Long, _
                                       ByVal rubyRatio As Double, _
                                       ByVal layoutMode As String, _
                                       ByVal xl As Object, _
                                       ByVal dict As Object) As Long

    Dim para As Paragraph
    Dim i As Long
    Dim pStart As Long
    Dim pEnd As Long
    Dim pos As Long
    Dim runStart As Long
    Dim runEnd As Long
    Dim r As Range
    Dim candidate As Range
    Dim txt As String
    Dim pageNo As Long
    Dim currentPage As Long
    Dim changed As Long

    ' 重要：
    ' mode=2/3 は「最初」を選ぶ必要があるが、処理順は必ず末尾→先頭。
    ' そのため対象を見つけても即処理せず、現在のページ／段落内で
    ' より先頭側にある候補へ更新し、ページ／段落の境界に到達した時点で
    ' 最も先頭側の候補だけを処理する。
    '
    ' これにより、事前に全Rangeを配列化する必要がなく、変更による
    ' Rangeオフセットのずれも回避できる。

    currentPage = -1
    Set candidate = Nothing

    For i = doc.Paragraphs.Count To 1 Step -1

        Set para = doc.Paragraphs(i)
        pStart = para.Range.Start
        pEnd = para.Range.End - 1

        If pEnd <= pStart Then GoTo NextParagraph

        pos = pEnd

        Do While pos > pStart

            txt = doc.Range(pos - 1, pos).Text

            If RubyIsTargetChar(txt) Then

                runEnd = pos
                runStart = pos - 1

                Do While runStart > pStart
                    txt = doc.Range(runStart - 1, runStart).Text
                    If RubyIsTargetChar(txt) Then
                        runStart = runStart - 1
                    Else
                        Exit Do
                    End If
                Loop

                Set r = doc.Range(runStart, runEnd)

                If Not RubyRangeAlreadyAnnotated(r) Then

                    If mode = 1 Then
                        changed = changed + RubyApplyReadingToRange( _
                                            r, level, singleMode, rubyRatio, xl, dict)

                    ElseIf mode = 2 Then
                        pageNo = RubyPageNumber(r)

                        If currentPage = -1 Then
                            currentPage = pageNo
                            Set candidate = r.Duplicate

                        ElseIf pageNo <> currentPage Then
                            ' ここまでで前ページの「最初の対象語」が確定。
                            changed = changed + RubyApplyReadingToRange( _
                                                candidate, level, singleMode, _
                                                rubyRatio, xl, dict)

                            Set candidate = r.Duplicate
                            currentPage = pageNo

                        Else
                            ' 同一ページで、さらに先頭側の候補へ更新
                            Set candidate = r.Duplicate
                        End If

                    ElseIf mode = 3 Then
                        ' 段落を逆方向に走査し、最終的に最も先頭側の対象を保持。
                        If candidate Is Nothing Then
                            Set candidate = r.Duplicate
                        Else
                            ' 現在の段落内で r は candidate より先頭側。
                            Set candidate = r.Duplicate
                        End If
                    End If
                End If

                pos = runStart
            Else
                pos = pos - 1
            End If

        Loop

        If mode = 3 Then
            If Not candidate Is Nothing Then
                changed = changed + RubyApplyReadingToRange( _
                                    candidate, level, singleMode, rubyRatio, xl, dict)
            End If
            Set candidate = Nothing
        End If

NextParagraph:
    Next i

    If mode = 2 Then
        If Not candidate Is Nothing Then
            changed = changed + RubyApplyReadingToRange( _
                                candidate, level, singleMode, rubyRatio, xl, dict)
        End If
    End If

    If RubyLayoutHas(layoutMode, "1") Then
        Call RubyFixLineSpacingReverse(doc)
    End If
    If RubyLayoutHas(layoutMode, "2") Then
        Call RubyFixTextBoxes(doc)
    End If
    If RubyLayoutHas(layoutMode, "3") Then
        Call RubyKeepPageBoundariesReverse(doc)
    End If

    RubyProcessAddReverse = changed
End Function

Private Function RubyApplyReadingToRange(ByVal target As Range, _
                                         ByVal level As Long, _
                                         ByVal singleMode As Long, _
                                         ByVal rubyRatio As Double, _
                                         ByVal xl As Object, _
                                         ByVal dict As Object) As Long

    Dim ruby As String
    Dim learned As Boolean

    If target Is Nothing Then Exit Function
    If RubyRangeAlreadyAnnotated(target) Then Exit Function

    learned = False
    ruby = RubyGetReading(target.Text, level, singleMode, xl, dict, target, learned)

    If ruby = vbNullString Then Exit Function

    If RubyApplyGuide(target, ruby, rubyRatio) Then
        RubyApplyReadingToRange = 1
    End If
End Function

' ---------------------------------------------------------------------------
' 削除処理：EQ フィールドとして実装された Word ルビを末尾→先頭で処理
' ---------------------------------------------------------------------------
Private Function RubyProcessDeleteReverse(ByVal doc As Document, _
                                          ByVal mode As Long, _
                                          ByVal layoutMode As String) As Long

    Dim i As Long
    Dim fld As Field
    Dim candidate As Field
    Dim pageNo As Long
    Dim currentPage As Long
    Dim paraNo As Long
    Dim currentPara As Long
    Dim changed As Long

    ' ルビはWord内部ではEQ（wdFieldFormula）フィールドとして保持される。
    ' 削除するとフィールド数とRange位置が変化するため、必ず末尾から処理する。
    '
    ' mode=5/6 は「最初のルビを残す」仕様。
    ' 逆順処理では、より先頭側のルビが見つかった時点で、それまで保持していた
    ' 後方側候補を削除し、新しい候補を保持する。
    ' 最終的にページ／段落の境界に到達したとき、保持候補が先頭の1件になる。

    currentPage = -1
    currentPara = -1
    Set candidate = Nothing

    For i = doc.Fields.Count To 1 Step -1

        Set fld = doc.Fields(i)

        If RubyIsRubyField(fld) Then

            Select Case mode

                Case 4
                    If RubyDeleteFieldGuide(fld) Then changed = changed + 1

                Case 5
                    pageNo = RubyPageNumber(fld.Code)

                    If currentPage = -1 Then
                        currentPage = pageNo
                        Set candidate = fld

                    ElseIf pageNo <> currentPage Then
                        ' 前ページのcandidateは、そのページの最初のルビ。
                        Set candidate = fld
                        currentPage = pageNo

                    Else
                        ' より先頭側のルビが見つかった。
                        ' 直前までのcandidateは重複なので削除する。
                        If Not candidate Is Nothing Then
                            If RubyDeleteFieldGuide(candidate) Then changed = changed + 1
                        End If
                        Set candidate = fld
                    End If

                Case 6
                    paraNo = RubyParagraphNumber(fld.Code)

                    If currentPara = -1 Then
                        currentPara = paraNo
                        Set candidate = fld

                    ElseIf paraNo <> currentPara Then
                        ' 前段落のcandidateはその段落の最初のルビ。
                        Set candidate = fld
                        currentPara = paraNo

                    Else
                        If Not candidate Is Nothing Then
                            If RubyDeleteFieldGuide(candidate) Then changed = changed + 1
                        End If
                        Set candidate = fld
                    End If

            End Select
        End If
    Next i

    ' candidateは最後に残した「最初のルビ」なので削除しない。

    If RubyLayoutHas(layoutMode, "1") Then
        Call RubyFixLineSpacingReverse(doc)
    End If
    If RubyLayoutHas(layoutMode, "2") Then
        Call RubyFixTextBoxes(doc)
    End If
    If RubyLayoutHas(layoutMode, "3") Then
        Call RubyKeepPageBoundariesReverse(doc)
    End If

    RubyProcessDeleteReverse = changed
End Function

' ---------------------------------------------------------------------------
' 読み取得
' ---------------------------------------------------------------------------
Private Function RubyGetReading(ByVal sourceText As String, _
                                ByVal level As Long, _
                                ByVal singleMode As Long, _
                                ByVal xl As Object, _
                                ByVal dict As Object, _
                                ByVal target As Range, _
                                ByRef learned As Boolean) As String

    Dim s As String
    Dim candidate As String
    Dim candidates As Collection

    sourceText = RubyNormalizeTarget(sourceText)
    If sourceText = vbNullString Then Exit Function

    ' カスタム辞書を最優先
    If dict.Exists(sourceText) Then
        RubyGetReading = RubyToHiragana(CStr(dict(sourceText)))
        Exit Function
    End If

    If level = 4 Then Exit Function

    ' 漢字の自動スキップ
    If RubyAllKanji(sourceText) Then
        If level = 2 And RubyContainsN5(sourceText) Then Exit Function
        If level = 3 And RubyContainsN5OrN4(sourceText) Then Exit Function
    End If

    If xl Is Nothing Then Exit Function

    ' 単漢字はユーザー指定方式
    If Len(sourceText) = 1 And RubyIsKanji(sourceText) Then

        Set candidates = RubyGetPhoneticCandidates(xl, sourceText)

        Select Case singleMode

            Case 1
                candidate = RubyPickOnReading(sourceText, candidates, xl)

            Case 2
                candidate = RubyPickKunReading(sourceText, candidates, xl)

            Case 3
                candidate = RubyInteractiveSingleKanji( _
                                target, sourceText, candidates, dict)

                If candidate <> vbNullString Then
                    dict(sourceText) = candidate
                    learned = True
                End If

        End Select

        RubyGetReading = RubyToHiragana(candidate)
        Exit Function
    End If

    ' 熟語・複合語・カタカナ語は Excel.GetPhonetic を利用
    On Error Resume Next
    s = CStr(xl.GetPhonetic(sourceText))
    If Err.Number <> 0 Then
        Err.Clear
        s = vbNullString
    End If
    On Error GoTo 0

    If s = vbNullString Then Exit Function

    RubyGetReading = RubyToHiragana(s)
End Function

Private Function RubyGetPhoneticCandidates(ByVal xl As Object, _
                                           ByVal sourceText As String) As Collection

    Dim c As New Collection
    Dim s As String
    Dim n As Long

    On Error Resume Next
    s = CStr(xl.GetPhonetic(sourceText))

    Do While s <> vbNullString And n < 20
        c.Add RubyToHiragana(s)
        n = n + 1
        s = CStr(xl.GetPhonetic())
        If Err.Number <> 0 Then
            Err.Clear
            Exit Do
        End If
    Loop
    On Error GoTo 0

    Set RubyGetPhoneticCandidates = c
End Function

Private Function RubyPickOnReading(ByVal kanji As String, _
                                   ByVal candidates As Collection, _
                                   ByVal xl As Object) As String

    Dim mapped As String
    Dim i As Long
    Dim s As String

    mapped = RubyKnownOnReading(kanji)
    If mapped <> vbNullString Then
        RubyPickOnReading = mapped
        Exit Function
    End If

    ' Excel候補のうち、一般的な単漢字音読みの長さを優先。
    ' 厳密な形態素解析ではないため、最終的には辞書登録を推奨。
    For i = 1 To candidates.Count
        s = CStr(candidates(i))
        If Len(s) >= 2 And Len(s) <= 4 Then
            RubyPickOnReading = s
            Exit Function
        End If
    Next i

    If candidates.Count > 0 Then RubyPickOnReading = CStr(candidates(1))
End Function

Private Function RubyPickKunReading(ByVal kanji As String, _
                                    ByVal candidates As Collection, _
                                    ByVal xl As Object) As String

    Dim mapped As String

    mapped = RubyKnownKunReading(kanji)
    If mapped <> vbNullString Then
        RubyPickKunReading = mapped
        Exit Function
    End If

    ' 明示マッピングがない場合は Excel の第一候補へフォールバック。
    If candidates.Count > 0 Then RubyPickKunReading = CStr(candidates(1))
End Function

' ---------------------------------------------------------------------------
' 単漢字対話選択
' ---------------------------------------------------------------------------
Private Function RubyInteractiveSingleKanji(ByVal target As Range, _
                                            ByVal kanji As String, _
                                            ByVal candidates As Collection, _
                                            ByVal dict As Object) As String

    Dim answer As String
    Dim i As Long
    Dim prompt As String
    Dim history As String

    On Error Resume Next
    target.Select
    ActiveWindow.ScrollIntoView Selection.Range, True
    On Error GoTo 0

    prompt = "単漢字「" & kanji & "」の読みを選択してください。" & vbCrLf & vbCrLf

    If dict.Exists(kanji) Then
        history = "履歴： " & CStr(dict(kanji)) & vbCrLf
    Else
        history = "履歴： なし" & vbCrLf
    End If

    prompt = prompt & history & vbCrLf & "Excel推測候補：" & vbCrLf

    For i = 1 To candidates.Count
        prompt = prompt & CStr(i) & "： " & CStr(candidates(i)) & vbCrLf
        If i >= 10 Then Exit For
    Next i

    prompt = prompt & vbCrLf & _
             "候補番号、または読みそのものを入力してください。" & vbCrLf & _
             "例：1 / 2 / かん" & vbCrLf & _
             "? または H でこの画面の詳細ヘルプを表示できます。"

    answer = RubyInputBoxWithHelp(prompt, _
                                   "RubyManager - 単漢字の読み", _
                                   RubyDefaultCandidate(candidates), _
                                   "現在の文字を画面中央付近へスクロールし、選択対象をハイライトします。" & vbCrLf & _
                                   "過去辞書がある場合は最優先候補として表示します。" & vbCrLf & _
                                   "候補番号を入力するとExcelの候補を採用します。" & vbCrLf & _
                                   "直接ひらがなを入力すると、その読みを学習辞書へ保存します。" & vbCrLf & _
                                   "キャンセルするとこの単漢字にはルビを付けません。")

    If answer = vbNullString Then Exit Function

    If IsNumeric(answer) Then
        i = CLng(answer)
        If i >= 1 And i <= candidates.Count Then
            RubyInteractiveSingleKanji = CStr(candidates(i))
            Exit Function
        End If
    End If

    answer = RubyToHiragana(Trim$(answer))
    If RubyContainsJapaneseKana(answer) Then
        RubyInteractiveSingleKanji = answer
    Else
        MsgBox "読みは、候補番号または日本語のひらがなで入力してください。", _
               vbExclamation, "RubyManager"
    End If
End Function

Private Function RubyDefaultCandidate(ByVal candidates As Collection) As String
    If candidates.Count > 0 Then RubyDefaultCandidate = CStr(candidates(1))
End Function

' ---------------------------------------------------------------------------
' ルビ追加・削除
' ---------------------------------------------------------------------------
Private Function RubyApplyGuide(ByVal target As Range, _
                                ByVal ruby As String, _
                                ByVal rubyRatio As Double) As Boolean

    Dim fs As Long
    Dim baseSize As Single

    On Error GoTo EH

    If target Is Nothing Then Exit Function
    If ruby = vbNullString Then Exit Function
    If RubyRangeAlreadyAnnotated(target) Then Exit Function

    baseSize = target.Font.Size
    If baseSize <= 0 Or baseSize = wdUndefined Then baseSize = 10

    fs = CLng(baseSize * rubyRatio / 100#)
    If fs < 4 Then fs = 4

    target.PhoneticGuide _
        Text:=RubyToHiragana(ruby), _
        Alignment:=wdPhoneticGuideAlignmentCenter, _
        Raise:=0, _
        FontSize:=fs, _
        FontName:=target.Font.Name

    RubyApplyGuide = True
    Exit Function

EH:
    RubyApplyGuide = False
End Function

Private Function RubyDeleteFieldGuide(ByVal fld As Field) As Boolean

    Dim oldSelStart As Long
    Dim oldSelEnd As Long

    On Error GoTo EH

    oldSelStart = Selection.Start
    oldSelEnd = Selection.End

    ' WordのルビはEQフィールドとして格納される。
    ' Field.ResultではPhoneticGuide ""が効かない場合があるため、
    ' フィールドそのものをSelectしてSelection.Rangeへ適用する。
    fld.Select
    Selection.Range.PhoneticGuide Text:=""

    On Error Resume Next
    Selection.SetRange Start:=oldSelStart, End:=oldSelEnd
    On Error GoTo 0

    RubyDeleteFieldGuide = True
    Exit Function

EH:
    RubyDeleteFieldGuide = False
End Function

Private Function RubyRangeAlreadyAnnotated(ByVal r As Range) As Boolean

    On Error Resume Next

    If r.Information(wdInFieldResult) Then
        RubyRangeAlreadyAnnotated = True
        Exit Function
    End If

    If r.Information(wdInFieldCode) Then
        RubyRangeAlreadyAnnotated = True
        Exit Function
    End If

    If r.Fields.Count > 0 Then
        Dim i As Long
        For i = 1 To r.Fields.Count
            If RubyIsRubyField(r.Fields(i)) Then
                RubyRangeAlreadyAnnotated = True
                Exit Function
            End If
        Next i
    End If

    On Error GoTo 0
End Function

Private Function RubyIsRubyField(ByVal fld As Field) As Boolean

    Dim code As String

    On Error Resume Next
    If fld.Type <> wdFieldFormula Then Exit Function

    code = fld.Code.Text
    code = LCase$(code)

    RubyIsRubyField = _
        (InStr(1, code, "\o", vbTextCompare) > 0 And _
         InStr(1, code, "\ad(", vbTextCompare) > 0 And _
         InStr(1, code, "\s\up", vbTextCompare) > 0)
End Function

' ---------------------------------------------------------------------------
' 対象文字・文字種判定
' ---------------------------------------------------------------------------
Private Function RubyIsTargetChar(ByVal s As String) As Boolean
    If Len(s) = 0 Then Exit Function
    RubyIsTargetChar = RubyIsKanji(s) Or RubyIsKatakana(s)
End Function

Private Function RubyIsKanji(ByVal s As String) As Boolean

    Dim u As Long
    If Len(s) = 0 Then Exit Function

    u = AscW(Left$(s, 1))
    If u < 0 Then u = u + 65536

    RubyIsKanji = _
        (u >= &H3400 And u <= &H4DBF) Or _
        (u >= &H4E00 And u <= &H9FFF) Or _
        (u >= &HF900 And u <= &HFAFF)
End Function

Private Function RubyIsKatakana(ByVal s As String) As Boolean

    Dim u As Long
    If Len(s) = 0 Then Exit Function

    u = AscW(Left$(s, 1))
    If u < 0 Then u = u + 65536

    RubyIsKatakana = _
        (u >= &H30A0 And u <= &H30FF) Or _
        (u >= &H31F0 And u <= &H31FF)
End Function

Private Function RubyAllKanji(ByVal s As String) As Boolean

    Dim i As Long
    If s = vbNullString Then Exit Function

    RubyAllKanji = True
    For i = 1 To Len(s)
        If Not RubyIsKanji(Mid$(s, i, 1)) Then
            RubyAllKanji = False
            Exit Function
        End If
    Next i
End Function

Private Function RubyContainsJapaneseKana(ByVal s As String) As Boolean

    Dim i As Long
    For i = 1 To Len(s)
        If RubyIsHiragana(Mid$(s, i, 1)) Or RubyIsKatakana(Mid$(s, i, 1)) Then
            RubyContainsJapaneseKana = True
            Exit Function
        End If
    Next i
End Function

Private Function RubyIsHiragana(ByVal s As String) As Boolean

    Dim u As Long
    If Len(s) = 0 Then Exit Function

    u = AscW(Left$(s, 1))
    If u < 0 Then u = u + 65536

    RubyIsHiragana = (u >= &H3040 And u <= &H309F)
End Function

Private Function RubyNormalizeTarget(ByVal s As String) As String
    s = Replace(s, vbCr, vbNullString)
    s = Replace(s, ChrW(7), vbNullString)
    RubyNormalizeTarget = Trim$(s)
End Function

Private Function RubyToHiragana(ByVal s As String) As String

    Dim i As Long
    Dim u As Long
    Dim c As String
    Dim result As String

    For i = 1 To Len(s)
        c = Mid$(s, i, 1)
        u = AscW(c)
        If u < 0 Then u = u + 65536

        ' カタカナ → ひらがな（Unicode上で0x60差）
        If u >= &H30A1 And u <= &H30F6 Then
            result = result & ChrW$(u - &H60)
        Else
            result = result & c
        End If
    Next i

    RubyToHiragana = result
End Function

' ---------------------------------------------------------------------------
' ページ・段落判定
' ---------------------------------------------------------------------------
Private Function RubyPageNumber(ByVal r As Range) As Long
    On Error Resume Next
    RubyPageNumber = CLng(r.Information(wdActiveEndPageNumber))
    If RubyPageNumber < 1 Then RubyPageNumber = 1
End Function

Private Function RubyParagraphNumber(ByVal r As Range) As Long

    Dim p As Paragraph
    Dim doc As Document
    Dim i As Long

    On Error GoTo EH

    Set doc = r.Document

    ' Paragraph.IndexはWord VBAのParagraphオブジェクトでは安定した公開APIではないため、
    ' Start位置から逆引きする。処理対象は末尾からなので検索は早期終了可能。
    For i = doc.Paragraphs.Count To 1 Step -1
        Set p = doc.Paragraphs(i)
        If p.Range.Start <= r.Start Then
            RubyParagraphNumber = i
            Exit Function
        End If
    Next i

EH:
    If RubyParagraphNumber = 0 Then RubyParagraphNumber = 1
End Function

' ---------------------------------------------------------------------------
' レイアウト
' ---------------------------------------------------------------------------
Private Function RubyLayoutHas(ByVal layoutMode As String, _
                               ByVal code As String) As Boolean

    layoutMode = Replace(layoutMode, " ", vbNullString)

    If InStr(1, layoutMode, "4", vbBinaryCompare) > 0 Then
        RubyLayoutHas = True
    Else
        RubyLayoutHas = (InStr(1, layoutMode, code, vbBinaryCompare) > 0)
    End If
End Function

Private Function RubyValidateLayout(ByVal s As String) As Boolean

    Dim i As Long
    Dim c As String

    s = Replace(s, " ", vbNullString)
    If s = vbNullString Then Exit Function

    If s = "4" Then
        RubyValidateLayout = True
        Exit Function
    End If

    For i = 1 To Len(s)
        c = Mid$(s, i, 1)
        If InStr("0123", c) = 0 Then
            RubyValidateLayout = False
            Exit Function
        End If
    Next i

    RubyValidateLayout = True
End Function

Private Sub RubyFixLineSpacingReverse(ByVal doc As Document)

    Dim i As Long
    Dim p As Paragraph
    Dim r As Range
    Dim baseSize As Single
    Dim rubySize As Single
    Dim required As Single

    For i = doc.Paragraphs.Count To 1 Step -1

        Set p = doc.Paragraphs(i)
        Set r = p.Range

        baseSize = r.Font.Size
        If baseSize <= 0 Or baseSize = wdUndefined Then baseSize = 10

        ' ルビ標準比率50%を前提に、最低でも本文＋ルビ分を確保。
        rubySize = baseSize * 0.5
        required = baseSize + rubySize + 2

        With p.Format
            .LineSpacingRule = wdLineSpaceAtLeast
            If .LineSpacing < required Then .LineSpacing = required
        End With
    Next i
End Sub

Private Sub RubyFixTextBoxes(ByVal doc As Document)

    Dim i As Long
    Dim shp As Shape
    Dim j As Long
    Dim r As Range
    Dim fs As Single

    On Error Resume Next

    For i = doc.Shapes.Count To 1 Step -1

        Set shp = doc.Shapes(i)

        If shp.TextFrame.HasText Then
            shp.TextFrame.AutoSize = True

            ' AutoSizeで解消できない場合のみ文字サイズを段階的に縮小。
            j = 0
            Do While shp.TextFrame.Overflowing And j < 10
                Set r = shp.TextFrame.TextRange
                fs = r.Font.Size
                If fs <= 6 Or fs = wdUndefined Then Exit Do

                r.Font.Size = fs - 0.5
                j = j + 1
            Loop
        End If
    Next i

    On Error GoTo 0
End Sub

Private Sub RubyKeepPageBoundariesReverse(ByVal doc As Document)

    Dim i As Long
    Dim p As Paragraph

    ' 「ページ境界維持」は、ルビによる段落の分割を最小化するための
    ' KeepTogether + WidowControl 方式。元ページを完全固定するものではない。
    For i = doc.Paragraphs.Count To 1 Step -1
        Set p = doc.Paragraphs(i)
        If RubyParagraphContainsRuby(p) Then
            p.Format.KeepTogether = True
            p.Format.WidowControl = True
        End If
    Next i
End Sub

Private Function RubyParagraphContainsRuby(ByVal p As Paragraph) As Boolean

    Dim i As Long

    On Error Resume Next
    For i = 1 To p.Range.Fields.Count
        If RubyIsRubyField(p.Range.Fields(i)) Then
            RubyParagraphContainsRuby = True
            Exit Function
        End If
    Next i
    On Error GoTo 0
End Function

' ---------------------------------------------------------------------------
' Excel
' ---------------------------------------------------------------------------
Private Function RubyCreateExcel() As Object

    Dim xl As Object

    On Error Resume Next
    Set xl = CreateObject("Excel.Application")
    If Err.Number <> 0 Then
        Err.Clear
        Set xl = Nothing
    End If
    On Error GoTo 0

    Set RubyCreateExcel = xl
End Function

' ---------------------------------------------------------------------------
' INI 永続化：UTF-8
' ---------------------------------------------------------------------------
Private Sub RubyLoadConfig(ByVal path As String, _
                           ByRef cfg As TRubyConfig, _
                           ByVal dict As Object)

    Dim text As String
    Dim lines() As String
    Dim i As Long
    Dim line As String
    Dim section As String
    Dim p As Long
    Dim key As String
    Dim value As String

    cfg.LastMode = 1
    cfg.LastLevel = 1
    cfg.LastSingleMode = 1
    cfg.RubyRatio = 50
    cfg.LayoutMode = "0"

    If Dir$(path) = vbNullString Then Exit Sub

    text = RubyReadUtf8(path)
    If text = vbNullString Then Exit Sub

    lines = Split(Replace(text, vbCrLf, vbLf), vbLf)

    For i = LBound(lines) To UBound(lines)

        line = Trim$(lines(i))

        If line = vbNullString Then GoTo ContinueConfig
        If Left$(line, 1) = ";" Or Left$(line, 1) = "#" Then GoTo ContinueConfig

        If Left$(line, 1) = "[" And Right$(line, 1) = "]" Then
            section = Mid$(line, 2, Len(line) - 2)
            GoTo ContinueConfig
        End If

        p = InStr(1, line, "=", vbBinaryCompare)
        If p <= 1 Then GoTo ContinueConfig

        key = Trim$(Left$(line, p - 1))
        value = Mid$(line, p + 1)

        Select Case section
            Case "Settings"
                Select Case LCase$(key)
                    Case "version"
                    Case "lastmode"
                        If RubyTryLong(value, cfg.LastMode) = False Then cfg.LastMode = 1
                    Case "lastlevel"
                        If RubyTryLong(value, cfg.LastLevel) = False Then cfg.LastLevel = 1
                    Case "lastsinglemode"
                        If RubyTryLong(value, cfg.LastSingleMode) = False Then cfg.LastSingleMode = 1
                    Case "rubyratio"
                        If RubyTryDouble(value, cfg.RubyRatio) = False Then cfg.RubyRatio = 50
                    Case "layoutmode"
                        cfg.LayoutMode = value
                End Select

            Case "Dictionary"
                dict(key) = RubyToHiragana(value)
        End Select

ContinueConfig:
    Next i
End Sub

Private Sub RubySaveConfig(ByVal path As String, _
                           ByRef cfg As TRubyConfig, _
                           ByVal dict As Object)

    Dim text As String
    Dim k As Variant

    text = "[Settings]" & vbCrLf & _
           "Version=" & CONFIG_VERSION & vbCrLf & _
           "LastMode=" & CStr(cfg.LastMode) & vbCrLf & _
           "LastLevel=" & CStr(cfg.LastLevel) & vbCrLf & _
           "LastSingleMode=" & CStr(cfg.LastSingleMode) & vbCrLf & _
           "RubyRatio=" & RubyNumberToText(cfg.RubyRatio) & vbCrLf & _
           "LayoutMode=" & cfg.LayoutMode & vbCrLf & vbCrLf & _
           "[Dictionary]" & vbCrLf

    For Each k In dict.Keys
        If Trim$(CStr(k)) <> vbNullString Then
            text = text & CStr(k) & "=" & CStr(dict(k)) & vbCrLf
        End If
    Next k

    RubyWriteUtf8 path, text
End Sub

Private Function RubyReadUtf8(ByVal path As String) As String

    Dim stm As Object

    On Error GoTo EH

    Set stm = CreateObject("ADODB.Stream")
    stm.Type = 2 ' adTypeText
    stm.Charset = "utf-8"
    stm.Open
    stm.LoadFromFile path
    RubyReadUtf8 = stm.ReadText(-1)
    stm.Close
    Set stm = Nothing
    Exit Function

EH:
    RubyReadUtf8 = vbNullString
    On Error Resume Next
    If Not stm Is Nothing Then stm.Close
    Set stm = Nothing
End Function

Private Sub RubyWriteUtf8(ByVal path As String, ByVal text As String)

    Dim stm As Object

    On Error GoTo EH

    Set stm = CreateObject("ADODB.Stream")
    stm.Type = 2 ' adTypeText
    stm.Charset = "utf-8"
    stm.Open
    stm.WriteText text
    stm.SaveToFile path, 2 ' adSaveCreateOverWrite
    stm.Close
    Set stm = Nothing
    Exit Sub

EH:
    On Error Resume Next
    If Not stm Is Nothing Then stm.Close
    Set stm = Nothing
    Err.Raise vbObjectError + 2101, "RubyManager", _
              "ruby_config.ini のUTF-8保存に失敗しました。" & vbCrLf & _
              Err.Description
End Sub

' ---------------------------------------------------------------------------
' InputBox with context help
' ---------------------------------------------------------------------------
Private Function RubyInputBoxWithHelp(ByVal prompt As String, _
                                      ByVal title As String, _
                                      ByVal defaultValue As String, _
                                      ByVal helpText As String) As String

    Dim answer As String

    Do
        answer = InputBox(prompt, title, defaultValue)

        If answer = vbNullString Then
            RubyInputBoxWithHelp = vbNullString
            Exit Function
        End If

        If UCase$(Trim$(answer)) = "?" Or UCase$(Trim$(answer)) = "H" Then
            MsgBox helpText, vbInformation, title & " - コンテキスト詳細ヘルプ"
        Else
            RubyInputBoxWithHelp = Trim$(answer)
            Exit Function
        End If
    Loop
End Function

' ---------------------------------------------------------------------------
' 入力変換
' ---------------------------------------------------------------------------
Private Function RubyTryLong(ByVal text As String, ByRef value As Long) As Boolean

    Dim d As Double

    If Not RubyTryDouble(text, d) Then Exit Function

    If d <> Fix(d) Then Exit Function
    If d < -2147483648# Or d > 2147483647# Then Exit Function

    value = CLng(d)
    RubyTryLong = True
End Function

Private Function RubyTryDouble(ByVal text As String, ByRef value As Double) As Boolean

    Dim t As String

    t = Trim$(text)
    If t = vbNullString Then Exit Function

    On Error GoTo EH
    t = Replace(t, ".", Application.International(wdDecimalSeparator))
    value = CDbl(t)
    RubyTryDouble = True
    Exit Function

EH:
    RubyTryDouble = False
End Function

Private Function RubyNumberToText(ByVal d As Double) As String
    Dim s As String
    s = Format$(d, "0.##")
    s = Replace(s, Application.International(wdDecimalSeparator), ".")
    RubyNumberToText = s
End Function

' ---------------------------------------------------------------------------
' N5 / N4近似漢字リスト
' ---------------------------------------------------------------------------
Private Function RubyContainsN5(ByVal s As String) As Boolean

    Const N5 As String = "一右雨円王音下火花貝学気九休玉金空月犬見五口校左三山子四糸字耳七車手十出女小上森人水正生青夕石赤千川先早草足村大男竹中虫町天田土二日入年白八百文木本名目立力林六"
    RubyContainsN5 = RubyAllCharactersInList(s, N5)
End Function

Private Function RubyContainsN5OrN4(ByVal s As String) As Boolean

    Const N5N4 As String = "一右雨円王音下火花貝学気九休玉金空月犬見五口校左三山子四糸字耳七車手十出女小上森人水正生青夕石赤千川先早草足村大男竹中虫町天田土二日入年白八百文木本名目立力林六引羽雲園遠何科夏家歌画回会海絵外角楽活間丸岩顔汽記帰弓牛魚京強教近兄形計元言原戸古午後語工公広考行高黄合谷国黒今才細作算止市矢姉思紙寺自時室社弱首秋週春書少場色食心新親図数西声星晴切雪船線前組走多太体台地池知茶昼長鳥朝直通店点電刀冬当東答頭同道読内南肉馬売買麦半番父風分聞米歩母方北毎妹明鳴毛門夜野友用曜来里理話悪安暗医意育員院飲運泳駅央横屋温化荷界開階寒感漢館岸起期客究急級宮球去橋業曲局銀区苦具君係軽血決研県庫湖向幸港号根祭皿仕使始死指"
    RubyContainsN5OrN4 = RubyAllCharactersInList(s, N5N4)
End Function

Private Function RubyAllCharactersInList(ByVal s As String, _
                                         ByVal listText As String) As Boolean

    Dim i As Long

    If s = vbNullString Then Exit Function

    RubyAllCharactersInList = True

    For i = 1 To Len(s)
        If Not RubyIsKanji(Mid$(s, i, 1)) Then
            RubyAllCharactersInList = False
            Exit Function
        End If

        If InStr(1, listText, Mid$(s, i, 1), vbBinaryCompare) = 0 Then
            RubyAllCharactersInList = False
            Exit Function
        End If
    Next i
End Function

' ---------------------------------------------------------------------------
' 単漢字の明示的な優先読み
' ※ 未登録文字はExcel候補へフォールバック。
' ---------------------------------------------------------------------------
Private Function RubyKnownOnReading(ByVal kanji As String) As String

    Select Case kanji
        Case "一": RubyKnownOnReading = "いち"
        Case "右": RubyKnownOnReading = "う"
        Case "雨": RubyKnownOnReading = "う"
        Case "円": RubyKnownOnReading = "えん"
        Case "音": RubyKnownOnReading = "おん"
        Case "下": RubyKnownOnReading = "か"
        Case "火": RubyKnownOnReading = "か"
        Case "花": RubyKnownOnReading = "か"
        Case "学": RubyKnownOnReading = "がく"
        Case "気": RubyKnownOnReading = "き"
        Case "九": RubyKnownOnReading = "きゅう"
        Case "金": RubyKnownOnReading = "きん"
        Case "空": RubyKnownOnReading = "くう"
        Case "月": RubyKnownOnReading = "げつ"
        Case "犬": RubyKnownOnReading = "けん"
        Case "見": RubyKnownOnReading = "けん"
        Case "五": RubyKnownOnReading = "ご"
        Case "口": RubyKnownOnReading = "こう"
        Case "校": RubyKnownOnReading = "こう"
        Case "左": RubyKnownOnReading = "さ"
        Case "三": RubyKnownOnReading = "さん"
        Case "山": RubyKnownOnReading = "さん"
        Case "子": RubyKnownOnReading = "し"
        Case "四": RubyKnownOnReading = "し"
        Case "字": RubyKnownOnReading = "じ"
        Case "耳": RubyKnownOnReading = "じ"
        Case "七": RubyKnownOnReading = "しち"
        Case "車": RubyKnownOnReading = "しゃ"
        Case "手": RubyKnownOnReading = "しゅ"
        Case "十": RubyKnownOnReading = "じゅう"
        Case "出": RubyKnownOnReading = "しゅつ"
        Case "女": RubyKnownOnReading = "じょ"
        Case "小": RubyKnownOnReading = "しょう"
        Case "上": RubyKnownOnReading = "じょう"
        Case "森": RubyKnownOnReading = "しん"
        Case "人": RubyKnownOnReading = "じん"
        Case "水": RubyKnownOnReading = "すい"
        Case "正": RubyKnownOnReading = "せい"
        Case "生": RubyKnownOnReading = "せい"
        Case "青": RubyKnownOnReading = "せい"
        Case "石": RubyKnownOnReading = "せき"
        Case "赤": RubyKnownOnReading = "せき"
        Case "千": RubyKnownOnReading = "せん"
        Case "川": RubyKnownOnReading = "せん"
        Case "先": RubyKnownOnReading = "せん"
        Case "早": RubyKnownOnReading = "そう"
        Case "草": RubyKnownOnReading = "そう"
        Case "足": RubyKnownOnReading = "そく"
        Case "村": RubyKnownOnReading = "そん"
        Case "大": RubyKnownOnReading = "だい"
        Case "男": RubyKnownOnReading = "だん"
        Case "竹": RubyKnownOnReading = "ちく"
        Case "中": RubyKnownOnReading = "ちゅう"
        Case "町": RubyKnownOnReading = "ちょう"
        Case "天": RubyKnownOnReading = "てん"
        Case "田": RubyKnownOnReading = "でん"
        Case "土": RubyKnownOnReading = "ど"
        Case "二": RubyKnownOnReading = "に"
        Case "日": RubyKnownOnReading = "にち"
        Case "年": RubyKnownOnReading = "ねん"
        Case "白": RubyKnownOnReading = "はく"
        Case "八": RubyKnownOnReading = "はち"
        Case "百": RubyKnownOnReading = "ひゃく"
        Case "文": RubyKnownOnReading = "ぶん"
        Case "木": RubyKnownOnReading = "もく"
        Case "本": RubyKnownOnReading = "ほん"
        Case "名": RubyKnownOnReading = "めい"
        Case "目": RubyKnownOnReading = "もく"
        Case "立": RubyKnownOnReading = "りつ"
        Case "力": RubyKnownOnReading = "りょく"
        Case "林": RubyKnownOnReading = "りん"
        Case "六": RubyKnownOnReading = "ろく"
    End Select
End Function

Private Function RubyKnownKunReading(ByVal kanji As String) As String

    Select Case kanji
        Case "右": RubyKnownKunReading = "みぎ"
        Case "雨": RubyKnownKunReading = "あめ"
        Case "円": RubyKnownKunReading = "まる"
        Case "音": RubyKnownKunReading = "おと"
        Case "下": RubyKnownKunReading = "した"
        Case "火": RubyKnownKunReading = "ひ"
        Case "花": RubyKnownKunReading = "はな"
        Case "貝": RubyKnownKunReading = "かい"
        Case "学": RubyKnownKunReading = "まな"
        Case "気": RubyKnownKunReading = "き"
        Case "休": RubyKnownKunReading = "やす"
        Case "金": RubyKnownKunReading = "かね"
        Case "空": RubyKnownKunReading = "そら"
        Case "月": RubyKnownKunReading = "つき"
        Case "犬": RubyKnownKunReading = "いぬ"
        Case "見": RubyKnownKunReading = "み"
        Case "口": RubyKnownKunReading = "くち"
        Case "左": RubyKnownKunReading = "ひだり"
        Case "山": RubyKnownKunReading = "やま"
        Case "子": RubyKnownKunReading = "こ"
        Case "四": RubyKnownKunReading = "よ"
        Case "耳": RubyKnownKunReading = "みみ"
        Case "七": RubyKnownKunReading = "なな"
        Case "車": RubyKnownKunReading = "くるま"
        Case "手": RubyKnownKunReading = "て"
        Case "出": RubyKnownKunReading = "で"
        Case "女": RubyKnownKunReading = "おんな"
        Case "小": RubyKnownKunReading = "ちい"
        Case "上": RubyKnownKunReading = "うえ"
        Case "森": RubyKnownKunReading = "もり"
        Case "人": RubyKnownKunReading = "ひと"
        Case "水": RubyKnownKunReading = "みず"
        Case "生": RubyKnownKunReading = "い"
        Case "青": RubyKnownKunReading = "あお"
        Case "石": RubyKnownKunReading = "いし"
        Case "赤": RubyKnownKunReading = "あか"
        Case "川": RubyKnownKunReading = "かわ"
        Case "先": RubyKnownKunReading = "さき"
        Case "早": RubyKnownKunReading = "はや"
        Case "草": RubyKnownKunReading = "くさ"
        Case "足": RubyKnownKunReading = "あし"
        Case "村": RubyKnownKunReading = "むら"
        Case "大": RubyKnownKunReading = "おお"
        Case "男": RubyKnownKunReading = "おとこ"
        Case "竹": RubyKnownKunReading = "たけ"
        Case "中": RubyKnownKunReading = "なか"
        Case "町": RubyKnownKunReading = "まち"
        Case "天": RubyKnownKunReading = "あめ"
        Case "田": RubyKnownKunReading = "た"
        Case "土": RubyKnownKunReading = "つち"
        Case "日": RubyKnownKunReading = "ひ"
        Case "年": RubyKnownKunReading = "とし"
        Case "白": RubyKnownKunReading = "しろ"
        Case "八": RubyKnownKunReading = "や"
        Case "百": RubyKnownKunReading = "もも"
        Case "文": RubyKnownKunReading = "ふみ"
        Case "木": RubyKnownKunReading = "き"
        Case "本": RubyKnownKunReading = "もと"
        Case "名": RubyKnownKunReading = "な"
        Case "目": RubyKnownKunReading = "め"
        Case "立": RubyKnownKunReading = "た"
        Case "力": RubyKnownKunReading = "ちから"
        Case "林": RubyKnownKunReading = "はやし"
    End Select
End Function

